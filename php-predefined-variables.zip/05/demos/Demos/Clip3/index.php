<!DOCTYPE html>
<html>
    <head>
        <title>PHP Fundamentals</title>
		<link href="assets/styles.css" rel="stylesheet" type="text/css" />
    </head>
    <body>
        <div id="HeaderWrapper">
            <div id="Header">
                <a href="index.php"><img src="assets/hwl.jpg" border="0" alt=""></a>
                <h2>
                    Welcome!
                </h2>
            </div>        
        </div>
        <div id="Body" class="center">
            <div>
                <a href="aboutus.php?version=2">About Us</a> |
                <a href="newsletter.php">Join Our Newsletter</a>
            </div>
        </div>
	</body>
</html>