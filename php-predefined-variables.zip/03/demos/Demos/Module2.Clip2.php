<?php

//-- print out the associative array of the Environment Predefined Variable

print "<pre>";
print_r($_ENV);
print "</pre>";


print "<pre>";
print_r($_ENV['APACHE_RUN_USER']);
print "</pre>";