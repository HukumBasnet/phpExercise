<?php

echo $_SERVER['HTTP_HOST'];
