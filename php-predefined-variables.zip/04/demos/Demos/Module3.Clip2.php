<?php

//-- print out the associative array of the SERVER Predefined Variable

print "<pre>";
print_r($_SERVER);
print "</pre>";
