<?php


print $_SERVER['REQUEST_URI'];

