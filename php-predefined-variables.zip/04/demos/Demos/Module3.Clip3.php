<?php

print "<pre>";
print_r($_SERVER['PHP_SELF']);
print "</pre>";
